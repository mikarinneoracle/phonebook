CREATE TABLE phonebook (
     id         NUMBER GENERATED ALWAYS AS IDENTITY,
     firstname  VARCHAR2 (255),
     lastname   VARCHAR2 (255),
     phonenumber VARCHAR2 (50),
     countrycode VARCHAR2 (10)
 );

CREATE OR REPLACE PROCEDURE ADD_CONTACT (
   firstname    IN  VARCHAR2,
   lastname     IN  VARCHAR2,
   phonenumber  IN  VARCHAR2,
   countrycode  IN  VARCHAR2,
   id           OUT NUMBER
)
AS
BEGIN
   INSERT INTO PHONEBOOK (FIRSTNAME, LASTNAME, PHONENUMBER, COUNTRYCODE)
   VALUES (firstname, lastname, phonenumber, countrycode)
   RETURN ID INTO id;
 
EXCEPTION
   WHEN OTHERS
   THEN HTP.print(SQLERRM);
END;
/

BEGIN
ords.enable_schema (
         p_enabled               => TRUE,
         p_schema                => 'phonebook',
         p_url_mapping_type      => 'BASE_PATH',
         p_url_mapping_pattern   => 'api',
         p_auto_rest_auth        => TRUE
);
ords.define_module (    
        p_module_name            => 'phonebook',
        p_base_path              => '/phonebook/',
        p_items_per_page         => 5,
        p_status                 => 'PUBLISHED',
        p_comments               => NULL 
);
ords.define_template ( 
        p_module_name            => 'phonebook',
        p_pattern                => 'listing/',
        p_priority               => 0,
        p_etag_type              => 'HASH',
        p_etag_query             => NULL, 
        p_comments               => NULL 
);
ords.define_handler (
        p_module_name            => 'phonebook',
        p_pattern                => 'listing/',
        p_method                 => 'GET', 
        p_source_type            => 'json/collection',
        p_items_per_page         => 5,
        p_mimes_allowed          => '',
        p_comments               => 'lists contacts in the phonebook in sets of 5. Use recursively.',
        p_source                 => 'select id, firstname, lastname, firstname || '' '' || lastname as fullname, phonenumber, countrycode from phonebook order by fullname'
);
ords.define_template (
        p_module_name            => 'phonebook',
        p_pattern                => 'listing/fullname/:fullname',
        p_priority               => 0,
        p_etag_type              => 'HASH',
        p_etag_query             => NULL,
        p_comments               => NULL
);
ords.define_handler (
        p_module_name            => 'phonebook',
        p_pattern                => 'listing/fullname/:fullname',
        p_method                 => 'GET',
        p_source_type            => 'json/collection',
        p_items_per_page         => 5,
        p_mimes_allowed          => '',
        p_comments               => 'searches for contacts in the phonebook by given name and lists found in sets of 5. Use recursively.',
        p_source                 => 'select id, firstname, lastname, firstname || '' '' || lastname as fullname, phonenumber, countrycode from phonebook where firstname || '' '' || lastname like :fullname order by fullname'
);
ords.define_handler (
        p_module_name           => 'phonebook',
        p_pattern               => 'listing/',
        p_method                => 'POST',
        p_source_type           => 'plsql/block',
        p_items_per_page        =>  0,
        p_mimes_allowed         => '',
        p_comments              => 'adds a contact to phonebook from the post data',
        p_source                => 
'
    declare
        -- id NUMBER;
    BEGIN
        ADD_CONTACT(firstname    => :firstname,
                lastname     => :lastname,
                phonenumber  => :phonenumber,
                countrycode  => :countrycode,
                id           => :id);
    commit;
    END;
'
);
ORDS.DEFINE_PARAMETER(
      p_module_name        => 'phonebook',
      p_pattern            => 'listing/',
      p_method             => 'POST',
      p_name               => 'id',
      p_bind_variable_name => 'id',
      p_source_type        => 'RESPONSE',
      p_param_type         => 'INT',
      p_access_method      => 'OUT');    
ords.define_template ( 
        p_module_name            => 'phonebook',
        p_pattern                => 'listing/:id',
        p_priority               => 0,
        p_etag_type              => 'HASH',
        p_etag_query             => NULL, 
        p_comments               => NULL 
);
ords.define_handler (
        p_module_name            => 'phonebook',
        p_pattern                => 'listing/:id',
        p_method                 => 'GET', 
        p_source_type            => 'json/collection',
        p_items_per_page         => 1,
        p_mimes_allowed          => '',
        p_comments               => 'gets a contact from phonebook by id',
        p_source                 => 'select firstname, lastname, phonenumber, countrycode from phonebook where id = :id'   
);
ords.define_handler (
        p_module_name            => 'phonebook',
        p_pattern                => 'listing/:id',
        p_method                 => 'PUT', 
        p_source_type            => 'plsql/block',
        p_items_per_page         => 0,
        p_mimes_allowed          => '',
        p_comments               => 'updates a contact in the phonebook by id and post data',
        p_source                 => 'update phonebook set firstname = :firstname, lastname = :lastname, phonenumber = :phonenumber, countrycode = :countrycode where id = :id' 
);
ords.define_handler (
        p_module_name            => 'phonebook',
        p_pattern                => 'listing/:id',
        p_method                 => 'DELETE', 
        p_source_type            => 'plsql/block',
        p_items_per_page         => 0,
        p_mimes_allowed          => '',
        p_comments               => 'deletes a contact in the phonebook by id',
        p_source                 => 'delete from phonebook where id = :id'
 );
 COMMIT;
 END;
 /