#!/bin/bash
# Copyright (c) 2019 Oracle and/or its affiliates. All rights reserved.
# Licensed under the Universal Permissive License v 1.0 as shown at http://oss.oracle.com/licenses/upl.
#
#
# Description: Sets up phonebook "Monolite".
# Return codes: 0 =
# DO NOT ALTER OR REMOVE COPYRIGHT NOTICES OR THIS HEADER.
#

get_object() {
    out_file=$1
    os_uri=$2
    success=1
    for i in $(seq 1 9); do
        echo "trying ($i) $2"
        http_status=$(curl -w '%%{http_code}' -L -s -o $1 $2)
        if [ "$http_status" -eq "200" ]; then
            success=0
            echo "saved to $1"
            break 
        else
             sleep 15
        fi
    done
    return $success
}

yum -y install oracle-release-el7
yum-config-manager --enable ol7_oracle_instantclient
yum -y install oracle-instantclient19.3-basic oracle-instantclient19.3-jdbc oracle-instantclient19.3-sqlplus

ATP_DB_NAME=$(curl -L http://169.254.169.254/opc/v1/instance/metadata | jq -j ".db_name")
ATP_PW=$(curl -L http://169.254.169.254/opc/v1/instance/metadata | jq -j ".atp_pw")
ATP_ORDS_PW=$(curl -L http://169.254.169.254/opc/v1/instance/metadata | jq -j ".atp_ords_pw")
ATP_SQL_URI=$(curl -L http://169.254.169.254/opc/v1/instance/metadata | jq -j ".sql_par")
ATP_SQL2_URI=$(curl -L http://169.254.169.254/opc/v1/instance/metadata | jq -j ".sql2_par")
WALLET_URI=$(curl -L http://169.254.169.254/opc/v1/instance/metadata | jq -j ".wallet_par")

# get artifacts from object storage
get_object /root/wallet.64 $${WALLET_URI}
# Setup ATP wallet files
base64 --decode /root/wallet.64 > /root/wallet.zip
unzip /root/wallet.zip -d /usr/lib/oracle/19.3/client64/lib/network/admin/

# Init DB
get_object /root/atp_phonebook.sql $${ATP_SQL_URI}
sudo sqlplus admin/$${ATP_PW}@$${ATP_DB_NAME}_tp @/root/atp_phonebook.sql $${ATP_ORDS_PW} > /root/sql1_log.txt

get_object /root/atp_phonebook2.sql $${ATP_SQL2_URI}
sudo sqlplus phonebook/$${ATP_ORDS_PW}@$${ATP_DB_NAME}_tp @/root/atp_phonebook2.sql > /root/sql2_log.txt

