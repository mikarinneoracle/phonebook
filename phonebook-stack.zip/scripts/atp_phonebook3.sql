insert into phonebook (firstname, lastname, phonenumber, countrycode) values('Mika', 'Rinne', '+35840111222', 'FI');
insert into phonebook (firstname, lastname, phonenumber, countrycode) values('Petteri', 'Manninen', '+35840333444', 'FI');
insert into phonebook (firstname, lastname, phonenumber, countrycode) values('Mikko', 'Puhakka', '+35840555666', 'FI');
insert into phonebook (firstname, lastname, phonenumber, countrycode) values('Mickey', 'Mouse', '+1-222-333-444', 'US');
insert into phonebook (firstname, lastname, phonenumber, countrycode) values('Donald', 'Duck', '+1-555-666-777', 'US');
select * from phonebook;